package com.example.autoalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import java.util.Calendar

object AlarmScheduler {
    fun rescheduleAll(context: Context) {
        val items = AlarmStore.all(context)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        items.forEach { item ->
            val pi = pending(context, item.id)
            am.cancel(pi)
            if (item.enabled && item.days.isNotEmpty()) {
                val next = nextTime(item.hour, item.minute, item.days)
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
                }
            }
        }
    }

    fun scheduleOne(context: Context, item: AlarmItem) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context, item.id)
        am.cancel(pi)
        if (item.enabled && item.days.isNotEmpty() &&
            (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                nextTime(item.hour, item.minute, item.days), pi)
        }
    }

    private fun pending(context: Context, id: Int): PendingIntent =
        PendingIntent.getBroadcast(context, id,
            Intent(context, AlarmReceiver::class.java).setAction("com.example.autoalarm.RING").putExtra("alarm_id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun nextTime(hour: Int, minute: Int, days: Set<Int>): Long {
        val now = Calendar.getInstance()
        for (offset in 0..7) {
            val c = Calendar.getInstance().apply {
                timeInMillis = now.timeInMillis
                add(Calendar.DAY_OF_YEAR, offset)
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (c.get(Calendar.DAY_OF_WEEK) in days && c.timeInMillis > now.timeInMillis) return c.timeInMillis
        }
        return now.timeInMillis + 60_000
    }
}
