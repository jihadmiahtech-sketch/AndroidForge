package com.example.autoalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("alarm_id", -1)
        val item = AlarmStore.all(context).firstOrNull { it.id == id } ?: return
        if (!item.enabled) return
        val service = Intent(context, AlarmService::class.java).putExtra("alarm_id", id)
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service) else context.startService(service)
        // Schedule the next occurrence for this recurring alarm.
        AlarmScheduler.scheduleOne(context, item)
    }
}
