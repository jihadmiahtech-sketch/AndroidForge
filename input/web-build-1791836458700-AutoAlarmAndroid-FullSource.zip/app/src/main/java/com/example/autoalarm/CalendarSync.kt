package com.example.autoalarm

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.util.Calendar

object CalendarSync {
    /**
     * Imports upcoming device-calendar events into alarms. Android's Calendar provider
     * includes Google calendars synced to the phone when the user has granted access.
     * This is event-to-alarm import; it does not write alarms back into Google Calendar.
     */
    fun importUpcomingEvents(context: Context, daysAhead: Int = 7): Int {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR)
            != PackageManager.PERMISSION_GRANTED) throw SecurityException("Calendar permission not granted")
        val now = System.currentTimeMillis()
        val end = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, daysAhead) }.timeInMillis
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().appendPath(now.toString()).appendPath(end.toString()).build()
        val projection = arrayOf(CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY)
        var count = 0
        context.contentResolver.query(uri, projection, null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
            val titleIx = c.getColumnIndex(CalendarContract.Instances.TITLE)
            val beginIx = c.getColumnIndex(CalendarContract.Instances.BEGIN)
            val allDayIx = c.getColumnIndex(CalendarContract.Instances.ALL_DAY)
            val existing = AlarmStore.all(context)
            while (c.moveToNext()) {
                if (c.getInt(allDayIx) == 1) continue
                val title = c.getString(titleIx)?.take(45)?.ifBlank { "Calendar event" } ?: "Calendar event"
                val cal = Calendar.getInstance().apply { timeInMillis = c.getLong(beginIx) }
                val days = setOf(cal.get(Calendar.DAY_OF_WEEK))
                val id = AlarmStore.nextId(context)
                existing.add(AlarmItem(id, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE),
                    title, true, days, null))
                count++
            }
            AlarmStore.save(context, existing)
            AlarmScheduler.rescheduleAll(context)
        }
        return count
    }
}
