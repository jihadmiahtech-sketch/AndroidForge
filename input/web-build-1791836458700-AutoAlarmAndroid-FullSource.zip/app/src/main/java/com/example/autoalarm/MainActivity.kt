package com.example.autoalarm

import android.Manifest
import android.app.AlarmManager
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    private val dayChecks = mutableListOf<CheckBox>()
    private var chosenHour = 7
    private var chosenMinute = 0
    private var ringtoneUri: String? = null
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("auto_alarm", Context.MODE_PRIVATE)
        AppCompatDelegate.setDefaultNightMode(if (prefs.getBoolean("dark", false))
            AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        requestPermissionsIfNeeded()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 32, 24, 24) }
        root.addView(TextView(this).apply { text = "Auto Alarm | অটো অ্যালার্ম"; textSize = 26f })
        root.addView(TextView(this).apply { text = "Smart Wake • Better Day"; textSize = 16f; setPadding(0, 8, 0, 18) })
        root.addView(Button(this).apply {
            text = "নতুন অ্যালার্ম / Add alarm"
            setOnClickListener { createAlarmDialog() }
        })
        root.addView(Button(this).apply {
            text = "রিংটোন বাছুন / Choose ringtone"
            setOnClickListener { chooseRingtone() }
        })
        root.addView(Button(this).apply {
            text = "Dark Mode চালু/বন্ধ"
            setOnClickListener {
                val next = !prefs.getBoolean("dark", false)
                prefs.edit().putBoolean("dark", next).apply()
                AppCompatDelegate.setDefaultNightMode(if (next) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
            }
        })
        root.addView(Button(this).apply {
            text = "Google Calendar থেকে ইভেন্ট আনুন / Import events"
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED) importCalendar()
                else ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.READ_CALENDAR), 501)
            }
        })
        root.addView(TextView(this).apply {
            text = "ক্যালেন্ডার ইভেন্ট ফোনে সিঙ্ক থাকা দরকার। এই সংস্করণে ইভেন্ট থেকে অ্যালার্ম আমদানি হয়; Calendar-এ ফেরত সিঙ্ক নয়।"
            textSize = 13f; setPadding(0, 4, 0, 12)
        })
        root.addView(TextView(this).apply { text = "আপনার অ্যালার্ম / Your alarms"; textSize = 20f; setPadding(0, 12, 0, 8) })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        setContentView(root)
        refreshAlarms()
    }

    private fun createAlarmDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 12, 24, 4) }
        val label = EditText(this).apply { hint = "নাম / Label (e.g. Work)" }
        box.addView(label)
        dayChecks.clear()
        val daysBn = listOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহঃ", "শুক্র", "শনি")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        daysBn.forEachIndexed { index, day ->
            val cb = CheckBox(this).apply { text = day; isChecked = index in 0..4 }
            dayChecks.add(cb); row.addView(cb)
        }
        box.addView(row)
        android.app.AlertDialog.Builder(this).setTitle("সময় বাছুন / Choose time").setView(box)
            .setPositiveButton("সময় নির্বাচন / Select time") { _, _ ->
                TimePickerDialog(this, { _, h, m ->
                    chosenHour = h; chosenMinute = m
                    val days = dayChecks.mapIndexedNotNull { i, cb -> if (cb.isChecked) i + 1 else null }.toSet()
                    if (days.isEmpty()) { Toast.makeText(this, "অন্তত একদিন বাছুন", Toast.LENGTH_SHORT).show(); return@TimePickerDialog }
                    val id = AlarmStore.nextId(this)
                    val item = AlarmItem(id, h, m, label.text.toString().ifBlank { "Alarm" }, true, days, ringtoneUri)
                    val all = AlarmStore.all(this); all.add(item); AlarmStore.save(this, all)
                    ensureExactAlarmPermission()
                    AlarmScheduler.scheduleOne(this, item)
                    refreshAlarms()
                }, chosenHour, chosenMinute, false).show()
            }.setNegativeButton("বাতিল / Cancel", null).show()
    }

    private fun refreshAlarms() {
        listBox.removeAllViews()
        val items = AlarmStore.all(this)
        if (items.isEmpty()) listBox.addView(TextView(this).apply { text = "এখনো অ্যালার্ম নেই / No alarms yet" })
        items.forEach { item ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
            val time = String.format("%02d:%02d", item.hour, item.minute)
            row.addView(TextView(this).apply {
                text = "$time  ${item.label}\n${item.days.sorted().joinToString { dayName(it) }}"
                textSize = 16f; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            row.addView(Button(this).apply {
                text = if (item.enabled) "ON" else "OFF"
                setOnClickListener {
                    val all = AlarmStore.all(this@MainActivity)
                    val index = all.indexOfFirst { it.id == item.id }
                    if (index >= 0) {
                        all[index] = all[index].copy(enabled = !all[index].enabled)
                        AlarmStore.save(this@MainActivity, all)
                        AlarmScheduler.scheduleOne(this@MainActivity, all[index])
                        refreshAlarms()
                    }
                }
            })
            row.addView(Button(this).apply {
                text = "×"
                setOnClickListener {
                    AlarmStore.save(this@MainActivity, AlarmStore.all(this@MainActivity).filterNot { it.id == item.id })
                    AlarmScheduler.rescheduleAll(this@MainActivity); refreshAlarms()
                }
            })
            listBox.addView(row)
        }
    }

    private fun dayName(d: Int) = listOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহঃ", "শুক্র", "শনি").getOrElse(d - 1) { "?" }

    private fun chooseRingtone() {
        val i = Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_ALARM)
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TITLE, "Choose alarm ringtone")
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
        }
        @Suppress("DEPRECATION") startActivityForResult(i, 200)
    }

    @Deprecated("Legacy callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 200 && resultCode == RESULT_OK && data != null) {
            val uri = data.getParcelableExtra<Uri>(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            ringtoneUri = uri?.toString()
            Toast.makeText(this, "নতুন অ্যালার্মে এই রিংটোন ব্যবহার হবে", Toast.LENGTH_SHORT).show()
        }
    }

    private fun importCalendar() {
        try {
            val count = CalendarSync.importUpcomingEvents(this)
            Toast.makeText(this, "$count event(s) imported / ইভেন্ট আনা হয়েছে", Toast.LENGTH_LONG).show()
            refreshAlarms()
        } catch (e: Exception) {
            Toast.makeText(this, "Calendar import failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 500)
    }

    private fun ensureExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        }
    }

    override fun onResume() { super.onResume(); if (::listBox.isInitialized) refreshAlarms() }
}
