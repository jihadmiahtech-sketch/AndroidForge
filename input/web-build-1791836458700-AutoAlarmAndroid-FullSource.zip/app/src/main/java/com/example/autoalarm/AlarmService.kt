package com.example.autoalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder

class AlarmService : Service() {
    private var ringtone: Ringtone? = null
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel("alarm_channel", "Alarms", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getIntExtra("alarm_id", -1) ?: -1
        val item = AlarmStore.all(this).firstOrNull { it.id == id }
        val open = PendingIntent.getActivity(this, 4000 + id,
            Intent(this, AlarmActivity::class.java).putExtra("alarm_id", id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "alarm_channel")
                .setContentTitle(item?.label ?: "Auto Alarm")
                .setContentText("Tap to solve the puzzle and stop the alarm")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX)
                .setFullScreenIntent(open, true).setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle(item?.label ?: "Auto Alarm")
                .setContentText("Tap to stop").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentIntent(open).setOngoing(true).build()
        }
        startForeground(99, notification)
        try {
            val uri = item?.ringtone?.let { Uri.parse(it) }
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ringtone = RingtoneManager.getRingtone(this, uri).apply {
                if (Build.VERSION.SDK_INT >= 28) isLooping = true
                play()
            }
        } catch (_: Exception) {}
        startActivity(Intent(this, AlarmActivity::class.java).putExtra("alarm_id", id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        return START_STICKY
    }

    fun stopAlarm() {
        try { ringtone?.stop() } catch (_: Exception) {}
        ringtone = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { try { ringtone?.stop() } catch (_: Exception) {}; super.onDestroy() }
}
