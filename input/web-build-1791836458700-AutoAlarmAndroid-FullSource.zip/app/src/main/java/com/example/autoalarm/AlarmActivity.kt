package com.example.autoalarm

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AlarmActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getIntExtra("alarm_id", -1)
        val item = AlarmStore.all(this).firstOrNull { it.id == id }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 60, 32, 32) }
        box.addView(TextView(this).apply { text = "সময় হয়েছে! / Wake up!"; textSize = 30f })
        box.addView(TextView(this).apply { text = item?.label ?: "Auto Alarm"; textSize = 22f; setPadding(0, 16, 0, 24) })
        box.addView(Button(this).apply {
            text = "গণিতের ধাঁধা সমাধান করুন / Solve to stop"
            setOnClickListener {
                startActivity(Intent(this@AlarmActivity, MathChallengeActivity::class.java).putExtra("alarm_id", id))
                finish()
            }
        })
        setContentView(box)
    }
}
