package com.example.autoalarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class AlarmItem(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String,
    val enabled: Boolean,
    val days: Set<Int>, // Calendar day constants: Sunday=1 ... Saturday=7
    val ringtone: String?
)

object AlarmStore {
    private const val PREF = "auto_alarm"
    private const val KEY = "alarms"

    fun all(context: Context): MutableList<AlarmItem> {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return mutableListOf()
        return try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val daysJson = o.optJSONArray("days") ?: JSONArray()
                val days = (0 until daysJson.length()).map { daysJson.getInt(it) }.toSet()
                AlarmItem(o.getInt("id"), o.getInt("hour"), o.getInt("minute"),
                    o.optString("label", "Alarm"), o.optBoolean("enabled", true), days,
                    o.optString("ringtone", "").ifBlank { null })
            }
        } catch (_: Exception) { mutableListOf() }
    }

    fun save(context: Context, items: List<AlarmItem>) {
        val arr = JSONArray()
        items.forEach { item ->
            val o = JSONObject()
            o.put("id", item.id); o.put("hour", item.hour); o.put("minute", item.minute)
            o.put("label", item.label); o.put("enabled", item.enabled)
            o.put("days", JSONArray(item.days.sorted()))
            o.put("ringtone", item.ringtone ?: "")
            arr.put(o)
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun nextId(context: Context) = (all(context).maxOfOrNull { it.id } ?: 0) + 1
}
