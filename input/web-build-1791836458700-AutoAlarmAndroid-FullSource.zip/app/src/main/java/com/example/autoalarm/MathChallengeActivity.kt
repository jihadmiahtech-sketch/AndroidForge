package com.example.autoalarm

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MathChallengeActivity : AppCompatActivity() {
    private var answer = 0
    private var alarmId = -1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        alarmId = intent.getIntExtra("alarm_id", -1)
        val a = Random.nextInt(4, 13); val b = Random.nextInt(3, 10); answer = a * b
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 24) }
        box.addView(TextView(this).apply { text = "অ্যালার্ম বন্ধ করতে উত্তর দিন\nSolve to stop: $a × $b = ?"; textSize = 24f })
        val input = EditText(this).apply { hint = "উত্তর / Answer"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        box.addView(input)
        box.addView(Button(this).apply {
            text = "যাচাই / Check"
            setOnClickListener {
                if (input.text.toString().toIntOrNull() == answer) {
                    stopService(Intent(this@MathChallengeActivity, AlarmService::class.java))
                    Toast.makeText(this@MathChallengeActivity, "অ্যালার্ম বন্ধ / Alarm stopped", Toast.LENGTH_SHORT).show()
                    finish()
                } else input.error = "ভুল উত্তর, আবার চেষ্টা করুন / Try again"
            }
        })
        setContentView(box)
    }
}
