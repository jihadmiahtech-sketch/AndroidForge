# Auto Alarm — Android Studio source

## Included
- Bengali/English labels in the basic UI.
- Multiple alarms, label, weekday selection, enable/disable and delete.
- Exact alarm scheduling and rescheduling after reboot/time/timezone changes.
- Custom device alarm ringtone picker.
- Foreground media playback service, full-screen alarm activity and math puzzle stop flow.
- Dark mode toggle.
- Imports upcoming events from the Android calendar provider. Google calendars synced to the phone may appear here after permission is granted.

## Important limitations
- Calendar import currently creates alarm entries from events. It is **not a full bidirectional sync**: it does not create/update/delete Google Calendar events, does not track event changes or deduplicate repeat imports. Production-grade sync needs event IDs stored with alarms and robust update/delete rules.
- Calendar provider access depends on Google Calendar being synced on the phone. Direct Google Calendar API/OAuth sync needs a Google Cloud project, Calendar API enabled, OAuth consent configuration and sign-in implementation.
- Android manufacturers may restrict background execution. Test full-screen intent, battery optimization, reboot, Do Not Disturb and locked-screen behavior on real devices.
- The source is not guaranteed to build without adjustment; build and test with Android Studio/Gradle before installing. This environment did not run an Android build, so no APK is included.

## Build on a computer
1. Install Android Studio.
2. Open this project folder and allow Gradle sync.
3. Connect a test Android phone or use an emulator.
4. Select Build > Build APK(s).
5. Test alarm, permissions, restart and ringtone behavior.

## Mobile-only note
Building from a phone is possible in some Android IDE/cloud build setups but may require extra Gradle/SDK configuration. The ZIP is source code, not an installable APK.
