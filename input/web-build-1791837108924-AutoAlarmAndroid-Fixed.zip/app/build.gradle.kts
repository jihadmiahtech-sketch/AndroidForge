plugins {
    id("com.android.application")
}
android {
    namespace = "com.example.autoalarm"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.autoalarm"
        minSdk = 23
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
}
