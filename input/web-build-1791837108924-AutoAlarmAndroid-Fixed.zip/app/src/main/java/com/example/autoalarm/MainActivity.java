package com.example.autoalarm;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, list;
    private final ArrayList<AlarmItem> alarms = new ArrayList<>();
    private static final String PREF = "alarms";
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(18,24,38));
        getWindow().setNavigationBarColor(Color.rgb(18,24,38));
        load();
        render();
    }
    private void render() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(1);
        root.setPadding(22,28,22,24); root.setBackgroundColor(Color.rgb(18,24,38));
        scroll.addView(root);
        TextView title = new TextView(this); title.setText("⏰ Auto Alarm"); title.setTextSize(28); title.setTextColor(Color.WHITE); title.setPadding(0,0,0,8); root.addView(title);
        TextView sub = new TextView(this); sub.setText("সহজে অ্যালার্ম সেট করুন"); sub.setTextSize(16); sub.setTextColor(Color.LTGRAY); root.addView(sub);
        Button add = new Button(this); add.setText("+ নতুন অ্যালার্ম"); add.setOnClickListener(v -> chooseTime()); root.addView(add);
        TextView heading = new TextView(this); heading.setText("আপনার অ্যালার্ম"); heading.setTextSize(20); heading.setTextColor(Color.WHITE); heading.setPadding(0,22,0,8); root.addView(heading);
        list = new LinearLayout(this); list.setOrientation(1); root.addView(list);
        if (alarms.isEmpty()) { TextView empty = new TextView(this); empty.setText("এখনো কোনো অ্যালার্ম নেই। নতুন অ্যালার্ম চাপুন।"); empty.setTextColor(Color.LTGRAY); empty.setPadding(0,18,0,18); list.addView(empty); }
        for (AlarmItem a : alarms) addAlarmRow(a);
        TextView note = new TextView(this); note.setText("\nটিপস: ফোনের অ্যালার্ম পারমিশন/নোটিফিকেশন চালু রাখুন।"); note.setTextColor(Color.LTGRAY); root.addView(note);
        setContentView(scroll);
    }
    private void chooseTime() {
        Calendar now = Calendar.getInstance();
        new TimePickerDialog(this, (view,hour,minute) -> {
            Calendar c = Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,hour); c.set(Calendar.MINUTE,minute); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
            if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR,1);
            AlarmItem item = new AlarmItem((int)(System.currentTimeMillis()%1000000),hour,minute,c.getTimeInMillis(),true);
            alarms.add(item); schedule(item); save(); render();
            Toast.makeText(this,"অ্যালার্ম সেট হয়েছে",Toast.LENGTH_SHORT).show();
        },now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),true).show();
    }
    private void addAlarmRow(AlarmItem a) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(12,12,6,12); row.setBackgroundColor(Color.rgb(31,41,59));
        LinearLayout info = new LinearLayout(this); info.setOrientation(1);
        TextView time = new TextView(this); time.setText(String.format(Locale.getDefault(),"%02d:%02d",a.hour,a.minute)); time.setTextSize(27); time.setTextColor(Color.WHITE); info.addView(time);
        TextView status = new TextView(this); status.setText(a.enabled ? "চালু" : "বন্ধ"); status.setTextColor(Color.LTGRAY); info.addView(status);
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        Switch sw = new Switch(this); sw.setChecked(a.enabled); sw.setOnCheckedChangeListener((button,checked)->{a.enabled=checked;if(checked)schedule(a);else cancel(a);save();status.setText(checked?"চালু":"বন্ধ");}); row.addView(sw);
        Button del = new Button(this); del.setText("মুছুন"); del.setOnClickListener(v->{cancel(a);alarms.remove(a);save();render();}); row.addView(del);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,10); list.addView(row,lp);
    }
    private void schedule(AlarmItem a) {
        Intent i = new Intent(this,AlarmReceiver.class); i.putExtra("id",a.id);
        PendingIntent pi = PendingIntent.getBroadcast(this,a.id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        if(am!=null) am.setExact(AlarmManager.RTC_WAKEUP,a.when,pi);
    }
    private void cancel(AlarmItem a) {
        Intent i = new Intent(this,AlarmReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(this,a.id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); if(am!=null)am.cancel(pi);
    }
    private void save() {
        StringBuilder s=new StringBuilder();
        for(AlarmItem a:alarms)s.append(a.id).append(",").append(a.hour).append(",").append(a.minute).append(",").append(a.when).append(",").append(a.enabled).append("; ");
        getSharedPreferences(PREF,0).edit().putString("data",s.toString()).apply();
    }
    private void load() {
        String s=getSharedPreferences(PREF,0).getString("data","");
        for(String part:s.split(";"))try{String[] p=part.trim().split(","); if(p.length==5)alarms.add(new AlarmItem(Integer.parseInt(p[0]),Integer.parseInt(p[1]),Integer.parseInt(p[2]),Long.parseLong(p[3]),Boolean.parseBoolean(p[4])));}catch(Exception ignored){}
    }
}
