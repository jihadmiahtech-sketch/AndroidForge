package com.example.autoalarm;
import android.app.*;
import android.os.Bundle;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
public class RingingActivity extends Activity {
    private Ringtone ringtone;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);layout.setGravity(Gravity.CENTER);layout.setPadding(24,24,24,24);layout.setBackgroundColor(Color.rgb(18,24,38));
        TextView title=new TextView(this);title.setText("⏰ অ্যালার্ম বাজছে!");title.setTextSize(30);title.setTextColor(Color.WHITE);layout.addView(title);
        TextView puzzle=new TextView(this);puzzle.setText("বন্ধ করতে 7 + 5 = কত?");puzzle.setTextSize(20);puzzle.setTextColor(Color.WHITE);puzzle.setPadding(0,24,0,16);layout.addView(puzzle);
        EditText answer=new EditText(this);answer.setHint("উত্তর লিখুন");answer.setInputType(2);layout.addView(answer);
        Button stop=new Button(this);stop.setText("অ্যালার্ম বন্ধ করুন");layout.addView(stop);
        stop.setOnClickListener(v->{if("12".equals(answer.getText().toString().trim())){if(ringtone!=null)ringtone.stop();finish();}else Toast.makeText(this,"ভুল উত্তর, আবার চেষ্টা করুন",Toast.LENGTH_SHORT).show();});
        setContentView(layout);
        try { Uri uri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM); ringtone=RingtoneManager.getRingtone(this,uri); if(ringtone!=null)ringtone.play(); } catch(Exception ignored){}
    }
    @Override protected void onDestroy(){if(ringtone!=null)ringtone.stop();super.onDestroy();}
}
