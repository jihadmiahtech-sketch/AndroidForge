package com.example.autoalarm;
class AlarmItem {
    int id,hour,minute; long when; boolean enabled;
    AlarmItem(int id,int hour,int minute,long when,boolean enabled){this.id=id;this.hour=hour;this.minute=minute;this.when=when;this.enabled=enabled;}
}
