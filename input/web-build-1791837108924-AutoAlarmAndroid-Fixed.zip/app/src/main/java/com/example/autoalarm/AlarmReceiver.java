package com.example.autoalarm;
import android.content.*;
import android.app.*;
public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Intent show = new Intent(context,RingingActivity.class);
        show.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try { context.startActivity(show); } catch(Exception ignored) {}
    }
}
