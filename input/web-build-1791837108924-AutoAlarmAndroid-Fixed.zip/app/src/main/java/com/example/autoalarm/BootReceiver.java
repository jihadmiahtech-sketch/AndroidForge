package com.example.autoalarm;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        // Minimal build: alarms are stored locally; rescheduling after reboot can be added in a later version.
    }
}
