# Auto Alarm - simplified Android project

This is a simplified Java/Android Gradle project intended for building with AndroidForge.

Features:
- Create multiple one-time alarms
- Enable/disable and delete alarms
- Dark interface with Bangla labels
- Default device alarm ringtone
- Simple math question to dismiss ringing screen

Build notes:
- Android Gradle Plugin 8.7.3
- compileSdk 35, minSdk 23, targetSdk 32
- No third-party Android libraries required

Important limitations:
- This is a simplified starter build, not the full feature set previously discussed.
- Calendar sync, weekday routines, custom ringtone selection, and reliable reboot rescheduling are not included.
- Exact alarm behavior may vary by Android version and device settings.
- A successful APK build cannot be guaranteed until the cloud build logs confirm it.
